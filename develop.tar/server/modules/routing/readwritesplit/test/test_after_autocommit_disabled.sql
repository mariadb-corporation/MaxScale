use test;
select @@server_id;